require("dotenv").config();

const express = require("express");
const cors = require("cors");
const session = require("express-session");
const axios = require("axios");

const app = express();

const PORT = Number(process.env.PORT || 3000);

const FRONTEND_ORIGINS = (process.env.FRONTEND_ORIGIN || "http://127.0.0.1:5500")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);

const ASEH_TOKEN_URL =
    process.env.ASEH_TOKEN_URL ||
    "https://webapp.aseh.gob.mx/api.nomina.sc/api/auth/token";

const ASEH_NOMINA_URL =
    process.env.ASEH_NOMINA_URL ||
    "https://webapp.aseh.gob.mx/api.nomina.sc/api/nomina/consulta";

const SESSION_SECRET =
    process.env.SESSION_SECRET || "CAMBIAR_ESTO_EN_PRODUCCION";

const COOKIE_SECURE =
    String(process.env.COOKIE_SECURE).toLowerCase() === "true";

// Si el backend se publica detrás de un proxy HTTPS (Render, Railway, etc.),
// Express necesita confiar en el proxy para manejar correctamente cookies seguras.
if (COOKIE_SECURE) {
    app.set("trust proxy", 1);
}

app.use(
    cors({
        origin(origin, callback) {
            // Permite herramientas como curl/Postman que no envían Origin.
            if (!origin) {
                return callback(null, true);
            }

            if (FRONTEND_ORIGINS.includes(origin)) {
                return callback(null, true);
            }

            return callback(
                new Error(`Origen no permitido por CORS: ${origin}`)
            );
        },
        credentials: true,
        methods: ["GET", "POST", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Accept"]
    })
);

app.use(express.json({ limit: "100kb" }));

app.use(
    session({
        name: "aseh.sid",
        secret: SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        cookie: {
            httpOnly: true,
            secure: COOKIE_SECURE,
            sameSite: COOKIE_SECURE ? "none" : "lax",
            maxAge: 8 * 60 * 60 * 1000
        }
    })
);

app.get("/api/health", (req, res) => {
    res.json({
        ok: true,
        servicio: "aseh-nomina-backend"
    });
});

/*
 * LOGIN
 *
 * El navegador manda clientId/clientSecret al backend.
 * El backend obtiene el token directamente desde ASEH.
 * El token NO se devuelve al navegador: se guarda en la sesión del servidor.
 */
app.post("/api/auth/login", async (req, res) => {
    const { clientId, clientSecret } = req.body || {};

    if (!clientId || !clientSecret) {
        return res.status(400).json({
            ok: false,
            message: "Debe proporcionar clientId y clientSecret."
        });
    }

    try {
        const response = await axios.post(
            ASEH_TOKEN_URL,
            {
                clientId,
                clientSecret
            },
            {
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                timeout: 30000
            }
        );

        const data = response.data || {};

        const token =
            data.access_token ||
            data.accessToken ||
            data.token;

        if (!token) {
            return res.status(502).json({
                ok: false,
                message: "La API ASEH respondió, pero no devolvió access_token."
            });
        }

        const expiresIn = Number(
            data.expires_in ||
            data.expiresIn ||
            28800
        );

        req.session.aseh = {
            token,
            expiresAt: Date.now() + expiresIn * 1000,
            clientId
        };

        return res.json({
            ok: true,
            message: "Autenticación correcta.",
            expiresIn
        });
    } catch (error) {
        console.error(
            "Error ASEH /auth/token:",
            error.response?.status,
            error.response?.data || error.message
        );

        if (error.response) {
            const status = error.response.status;

            if (status === 400) {
                return res.status(400).json({
                    ok: false,
                    message: "Las credenciales proporcionadas no son válidas."
                });
            }

            if (status === 401) {
                return res.status(401).json({
                    ok: false,
                    message: "No autorizado. Verifique sus credenciales."
                });
            }

            if (status === 403) {
                return res.status(403).json({
                    ok: false,
                    message: "El acceso fue rechazado por la API ASEH."
                });
            }

            return res.status(502).json({
                ok: false,
                message: "La API ASEH respondió con un error.",
                upstreamStatus: status
            });
        }

        return res.status(502).json({
            ok: false,
            message: "No fue posible comunicarse con la API ASEH."
        });
    }
});

/*
 * ESTADO DE SESIÓN
 */
app.get("/api/auth/status", (req, res) => {
    const auth = req.session.aseh;

    if (!auth || !auth.token) {
        return res.json({
            authenticated: false
        });
    }

    if (auth.expiresAt && Date.now() >= auth.expiresAt) {
        req.session.destroy(() => {});
        return res.json({
            authenticated: false
        });
    }

    return res.json({
        authenticated: true,
        clientId: auth.clientId
    });
});

/*
 * LOGOUT
 */
app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            console.error("Error cerrando sesión:", error);
            return res.status(500).json({
                ok: false,
                message: "No fue posible cerrar la sesión."
            });
        }

        res.clearCookie("aseh.sid");
        return res.json({
            ok: true,
            message: "Sesión cerrada."
        });
    });
});

/*
 * CONSULTA DE NÓMINA
 *
 * El frontend NO manda el Bearer token.
 * El backend lo obtiene de la sesión y lo agrega a la petición ASEH.
 */
app.post("/api/nomina/consulta", async (req, res) => {
    const auth = req.session.aseh;

    if (!auth || !auth.token) {
        return res.status(401).json({
            ok: false,
            message: "No hay una sesión autenticada."
        });
    }

    if (auth.expiresAt && Date.now() >= auth.expiresAt) {
        req.session.destroy(() => {});
        return res.status(401).json({
            ok: false,
            message: "La sesión con la API ASEH ha expirado."
        });
    }

    const {
        ejercicio,
        trimestre,
        pagina,
        tamanoPagina
    } = req.body || {};

    if (
        ejercicio === undefined ||
        trimestre === undefined ||
        pagina === undefined ||
        tamanoPagina === undefined
    ) {
        return res.status(400).json({
            ok: false,
            message: "Faltan parámetros de consulta."
        });
    }

    const body = {
        ejercicio: Number(ejercicio),
        trimestre: String(trimestre),
        pagina: Number(pagina),
        tamanoPagina: Number(tamanoPagina)
    };

    try {
        const response = await axios.post(
            ASEH_NOMINA_URL,
            body,
            {
                headers: {
                    Authorization: `Bearer ${auth.token}`,
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                timeout: 120000
            }
        );

        return res.json(response.data);
    } catch (error) {
        console.error(
            "Error ASEH /nomina/consulta:",
            error.response?.status,
            error.response?.data || error.message
        );

        if (error.response) {
            const status = error.response.status;

            if (status === 401 || status === 403) {
                req.session.destroy(() => {});
                return res.status(401).json({
                    ok: false,
                    message: "El token ASEH ya no es válido. Inicie sesión nuevamente."
                });
            }

            if (status === 400) {
                return res.status(400).json({
                    ok: false,
                    message: "Los parámetros enviados no son válidos."
                });
            }

            return res.status(502).json({
                ok: false,
                message: "La API ASEH respondió con un error.",
                upstreamStatus: status
            });
        }

        return res.status(502).json({
            ok: false,
            message: "No fue posible comunicarse con la API ASEH."
        });
    }
});

app.use((error, req, res, next) => {
    if (error?.message?.startsWith("Origen no permitido por CORS:")) {
        return res.status(403).json({
            ok: false,
            message: error.message
        });
    }

    console.error("Error no controlado:", error);

    return res.status(500).json({
        ok: false,
        message: "Error interno del servidor."
    });
});

app.listen(PORT, () => {
    console.log("");
    console.log("==============================================");
    console.log("  BACKEND SISTEMA DE NÓMINA ASEH");
    console.log("==============================================");
    console.log(`  Puerto: ${PORT}`);
    console.log(`  Frontend permitido: ${FRONTEND_ORIGINS.join(", ")}`);
    console.log(`  Token ASEH: ${ASEH_TOKEN_URL}`);
    console.log(`  Nómina ASEH: ${ASEH_NOMINA_URL}`);
    console.log("==============================================");
    console.log("");
});
